# SQLAlchemy One-to-One Practice

This project follows the same basic style and flow as the Department -> Employee example, but changes the relationship to one-to-one.

## Relationship

```text
Employee2  1 -------- 1  EmpCard2
```

One employee can have one employee card, and one employee card belongs to one employee.

## Important change

In `empcard2.py`:

```python
employee_id = mapped_column(
    Integer,
    ForeignKey("employee2.id"),
    unique=True,
    nullable=False
)
```

The important part is `unique=True`.

Without `unique=True`:

```text
Employee 1 -> Card 1
Employee 1 -> Card 2   # possible
```

With `unique=True`:

```text
Employee 1 -> Card 1
Employee 1 -> Card 2   # NOT allowed
```

## Relationship objects

`Employee2` has:

```python
card: Mapped["EmpCard2"] = relationship(
    "EmpCard2",
    back_populates="employee",
    uselist=False
)
```

`EmpCard2` has:

```python
employee: Mapped["Employee2"] = relationship(
    "Employee2",
    back_populates="card"
)
```

## Practice order

Run these one at a time from `main2.py`:

1. `createemployee2()`
2. `createempcard2()`
3. `getemployee2()`
4. `getempcard2()`

## Important

The project uses the same MySQL URL style as the previous project. Change the password/database URL in `db/db_config.py` if needed for your local setup.
