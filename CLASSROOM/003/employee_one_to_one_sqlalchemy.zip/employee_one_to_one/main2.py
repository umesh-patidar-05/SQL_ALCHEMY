from sqlalchemy import select

from db.db_config import engine, Base, sessionlocal
from model.employee2 import Employee2
from model.empcard2 import EmpCard2

# Importing both models before create_all() is important.
Base.metadata.create_all(engine)
print("agar sab shi rha to dono table ban jaegiii")


# ------------------------------------------------------------
# CREATE EMPLOYEE
# ------------------------------------------------------------
def createemployee2():
    session = sessionlocal()

    emp = Employee2(
        name="deepika",
        email="dipu2@gmail.com",
        salary=9000
    )

    session.add(emp)
    session.commit()

    print("Employee2 will be added")
    print("Employee2 ID:", emp.id)

    session.close()


# ------------------------------------------------------------
# CREATE EMP CARD FOR EMPLOYEE
# ------------------------------------------------------------
def createempcard2():
    session = sessionlocal()

    emp = session.get(Employee2, 1)

    if emp is not None:
        card = EmpCard2(card_number="CARD-1001")

        # Relationship way:
        emp.card = card

        session.commit()

        print("EmpCard2 will be added")
        print("Employee ID:", card.employee_id)

    else:
        print("Employee2 not found")

    session.close()


# ------------------------------------------------------------
# GET EMPLOYEE WITH CARD
# ------------------------------------------------------------
def getemployee2():
    session = sessionlocal()

    stmt = select(Employee2)
    employees = session.scalars(stmt).all()

    for emp in employees:
        print("ID", emp.id)
        print("Name", emp.name)
        print("Email", emp.email)
        print("Salary", emp.salary)

        if emp.card is not None:
            print("Card ID", emp.card.card_id)
            print("Card Number", emp.card.card_number)
            print("Card Employee ID", emp.card.employee_id)
        else:
            print("Card not assigned")

    session.close()


# ------------------------------------------------------------
# GET CARD AND ITS EMPLOYEE
# ------------------------------------------------------------
def getempcard2():
    session = sessionlocal()

    stmt = select(EmpCard2)
    cards = session.scalars(stmt).all()

    for card in cards:
        print("Card ID", card.card_id)
        print("Card Number", card.card_number)
        print("Employee ID", card.employee.id)
        print("Employee Name", card.employee.name)

    session.close()


# Run one function at a time while practicing.
# createemployee2()
# createempcard2()
# getemployee2()
# getempcard2()
